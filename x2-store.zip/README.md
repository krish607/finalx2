# X2 Monochrome Store (Next.js)

Amazon-style black & white demo store with search, filters, cart, wishlist, and a simple settings/admin sheet.

## Run locally
```bash
npm install
npm run dev
# open http://localhost:3000
```

## Customize
- Click the ⚙️ (Settings) icon in the header to change Store Name & Hero text.
- Import/Export product JSON to modify the catalog. Each product needs:
  `{ id, title, price, rating, reviews, category, inStock, description, image }`.

## Deploy to Vercel
1. Push this folder to a new GitHub repo.
2. Go to Vercel → New Project → Import your repo.
3. Framework is detected automatically (Next.js). Build command: `next build`.
4. Deploy and get your live URL. Add a custom domain if you want.

### Notes
- This template ships with minimal UI components (Tailwind) to avoid extra setup. 
- Images are loaded from Unsplash and forced to grayscale.
