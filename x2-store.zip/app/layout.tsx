import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'X2 Monochrome Store',
  description: 'Amazon-style black & white demo store',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
