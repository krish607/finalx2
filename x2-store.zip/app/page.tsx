
'use client';
import React, { useMemo, useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetFooter } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import {
  ShoppingCart, Search, User, Settings, Menu, Heart, Truck, ShieldCheck, Star, X, Pencil, Upload, Download
} from "lucide-react";

interface Product {
  id: string;
  title: string;
  price: number;
  rating: number;
  reviews: number;
  category: string;
  inStock: boolean;
  description: string;
  image: string;
}
interface CartItem { id: string; qty: number; }

const rupee = (n: number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);

function Stars({ value }: { value: number }) {
  const full = Math.floor(value);
  const half = value - full >= 0.5;
  return (
    <div className="flex items-center gap-1" aria-label={`${value} out of 5`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className={`w-4 h-4 ${i < full ? "text-white" : half && i === full ? "opacity-70" : "opacity-40"}`} />
      ))}
    </div>
  );
}

const DEFAULT_PRODUCTS: Product[] = [
  {
    id: "p1",
    title: "X2 Wireless Earbuds (ANC)",
    price: 2999,
    rating: 4.4,
    reviews: 3124,
    category: "Electronics",
    inStock: true,
    description: "Lightweight earbuds with active noise cancellation and long battery life.",
    image: "https://images.unsplash.com/photo-1518444438453-9bf1db05f2d1?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&sat=-100",
  },
  {
    id: "p2",
    title: "The Monochrome Startup Handbook",
    price: 499,
    rating: 4.7,
    reviews: 876,
    category: "Books",
    inStock: true,
    description: "Build, launch, and scale products using simple, timeless principles.",
    image: "https://images.unsplash.com/photo-1519681393784-d120267933ba?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&sat=-100",
  },
  {
    id: "p3",
    title: "X2 Smart Kettle (1.7L)",
    price: 1899,
    rating: 4.2,
    reviews: 542,
    category: "Home",
    inStock: true,
    description: "Quick boil with auto shut-off and temperature hold modes.",
    image: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&sat=-100",
  },
  {
    id: "p4",
    title: "Minimalist Cotton Tee",
    price: 799,
    rating: 4.1,
    reviews: 201,
    category: "Fashion",
    inStock: true,
    description: "Soft, breathable cotton with a clean crew neck fit.",
    image: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&sat=-100",
  },
  {
    id: "p5",
    title: "STEM Line-Follower Robot Kit",
    price: 1499,
    rating: 4.5,
    reviews: 129,
    category: "Toys",
    inStock: true,
    description: "Hands-on robotics kit with sensors and step-by-step guide.",
    image: "https://images.unsplash.com/photo-1545670723-196ed0954983?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&sat=-100",
  },
  {
    id: "p6",
    title: "Ergonomic Office Chair",
    price: 7499,
    rating: 4.3,
    reviews: 988,
    category: "Home",
    inStock: false,
    description: "Lumbar support, breathable mesh, and silent casters.",
    image: "https://images.unsplash.com/photo-1582582429416-0eb0c7b06ab7?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&sat=-100",
  },
];

const LS_PRODUCTS = "x2_products";
const LS_WISHLIST = "x2_wishlist";
const LS_STORE = "x2_store";

function useLocalStorage<T>(key: string, initial: T) {
  const [state, setState] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initial;
    } catch {
      return initial;
    }
  });
  useEffect(() => {
    try { localStorage.setItem(key, JSON.stringify(state)); } catch {}
  }, [key, state]);
  return [state, setState] as const;
}

function StoreName() {
  const [store] = useLocalStorage(LS_STORE, { name: "X2", hero: "Minimal, fast, Amazon‑style shopping — in pure black & white." });
  return <div className="font-black text-2xl tracking-tight select-none">{store.name}</div>;
}

function CartSheet() {
  const [items, setItems] = useState<CartItem[]>(() => []);
  const add = (id: string) => setItems(prev => {
    const found = prev.find(i => i.id === id);
    if (found) return prev.map(i => i.id === id ? { ...i, qty: i.qty + 1 } : i);
    return [...prev, { id, qty: 1 }];
  });
  const remove = (id: string) => setItems(prev => prev.filter(i => i.id !== id));
  const change = (id: string, qty: number) => setItems(prev => prev.map(i => i.id === id ? { ...i, qty } : i));

  (globalThis as any).__x2_addToCart = add;
  (globalThis as any).__x2_cartCount = () => items.reduce((a, b) => a + b.qty, 0);

  const products: Product[] = JSON.parse(localStorage.getItem(LS_PRODUCTS) || "null") || DEFAULT_PRODUCTS;
  const withInfo = items.map(ci => ({ ...ci, product: products.find(p => p.id === ci.id)! }));
  const subtotal = withInfo.reduce((a, i) => a + i.product.price * i.qty, 0);

  return (
    <SheetContent side="right" className="w-full sm:max-w-md bg-black text-white">
      <SheetHeader><SheetTitle>Cart</SheetTitle></SheetHeader>
      <div className="mt-4 space-y-4">
        {withInfo.length === 0 ? (
          <div className="text-sm opacity-70">Your cart is empty.</div>
        ) : withInfo.map(i => (
          <div key={i.id} className="flex items-center gap-3">
            <div className="w-16 h-16 bg-white/10 rounded-xl overflow-hidden">
              <img src={i.product.image} alt="" className="w-full h-full object-cover" />
            </div>
            <div className="flex-1">
              <div className="font-medium line-clamp-2">{i.product.title}</div>
              <div className="text-sm opacity-70">{rupee(i.product.price)}</div>
              <div className="flex items-center gap-2 mt-1">
                <Button variant="outline" size="sm" className="rounded-xl" onClick={() => change(i.id, Math.max(1, i.qty - 1))}>-</Button>
                <div className="text-sm">{i.qty}</div>
                <Button variant="outline" size="sm" className="rounded-xl" onClick={() => change(i.id, i.qty + 1)}>+</Button>
                <Button variant="ghost" size="sm" className="rounded-xl" onClick={() => remove(i.id)}><X className="w-4 h-4"/></Button>
              </div>
            </div>
            <div className="text-right font-semibold">{rupee(i.product.price * i.qty)}</div>
          </div>
        ))}
      </div>
      <Separator className="my-4"/>
      <div className="flex items-center justify-between">
        <div className="text-sm opacity-70">Subtotal</div>
        <div className="text-lg font-bold">{rupee(subtotal)}</div>
      </div>
      <SheetFooter className="mt-4">
        <Button className="w-full rounded-2xl">Proceed to Checkout</Button>
      </SheetFooter>
    </SheetContent>
  );
}

function ProductCard({ p, onOpen }: { p: Product; onOpen: (p: Product) => void }) {
  const add = () => (globalThis as any).__x2_addToCart?.(p.id);
  const [wishlist, setWishlist] = useLocalStorage<string[]>(LS_WISHLIST, []);
  const liked = wishlist.includes(p.id);
  const toggleWish = () => setWishlist(prev => prev.includes(p.id) ? prev.filter(x => x !== p.id) : [...prev, p.id]);
  return (
    <Card className="rounded-2xl border border-white/10">
      <CardContent className="p-4">
        <div className="aspect-[4/3] rounded-xl bg-white/10 overflow-hidden mb-3">
          <img src={p.image} alt="" className="w-full h-full object-cover" />
        </div>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="font-medium leading-tight line-clamp-2">{p.title}</div>
            <div className="flex items-center gap-2 mt-1">
              <Stars value={p.rating} />
              <span className="text-xs opacity-60">({p.reviews})</span>
            </div>
            <div className="mt-2 text-lg font-bold">{rupee(p.price)}</div>
            <div className={`mt-1 text-xs ${p.inStock ? "" : "opacity-60"}`}>{p.inStock ? "In stock" : "Out of stock"}</div>
          </div>
          <div className="flex flex-col gap-2 shrink-0">
            <Button variant="outline" size="icon" className="rounded-xl" onClick={() => onOpen(p)}>i</Button>
            <Button size="icon" className="rounded-xl" onClick={add}><ShoppingCart className="w-4 h-4"/></Button>
            <Button variant={liked ? "default" : "ghost"} size="icon" className="rounded-xl" onClick={toggleWish}><Heart className="w-4 h-4"/></Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function ProductDialog({ product, onClose }: { product: Product | null; onClose: () => void }) {
  const add = () => product && (globalThis as any).__x2_addToCart?.(product.id);
  if (!product) return null;
  return (
    <Dialog open={!!product}>
      <DialogContent onInteractOutside={onClose} className="rounded-2xl max-w-3xl">
        <DialogHeader>
          <DialogTitle>{product?.title}</DialogTitle>
          <DialogDescription className="opacity-70">{product?.category}</DialogDescription>
        </DialogHeader>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="aspect-square rounded-xl bg-white/10 overflow-hidden">
            <img src={product.image} alt="" className="w-full h-full object-cover"/>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-2"><Stars value={product?.rating || 0}/><span className="text-xs opacity-60">{product?.reviews} reviews</span></div>
            <div className="text-2xl font-bold mb-2">{rupee(product.price)}</div>
            <p className="text-sm opacity-80 mb-4">{product?.description}</p>
            <div className="flex items-center gap-2">
              <Button className="rounded-2xl" onClick={add}><ShoppingCart className="w-4 h-4 mr-2"/>Add to cart</Button>
              <Button variant="outline" className="rounded-2xl" onClick={onClose}>Close</Button>
            </div>
            <div className="mt-6 grid grid-cols-3 gap-3 text-sm">
              <div className="border border-white/10 rounded-xl p-3 flex items-center gap-2"><Truck className="w-4 h-4"/>Fast delivery</div>
              <div className="border border-white/10 rounded-xl p-3 flex items-center gap-2"><ShieldCheck className="w-4 h-4"/>Secure checkout</div>
              <div className="border border-white/10 rounded-xl p-3 flex items-center gap-2"><Heart className="w-4 h-4"/>Wishlist ready</div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Filters({ category, setCategory, query, setQuery, sort, setSort, categories }:{ category:string; setCategory:(c:string)=>void; query:string; setQuery:(q:string)=>void; sort:string; setSort:(s:string)=>void; categories:string[]; }) {
  return (
    <div className="sticky top-[4.25rem] space-y-3">
      <div className="font-semibold">Filters</div>
      <div>
        <Label className="text-xs opacity-70">Search</Label>
        <Input value={query} onChange={e => setQuery(e.target.value)} className="rounded-xl bg-white text-black placeholder-black/50" placeholder="Find products"/>
      </div>
      <div>
        <Label className="text-xs opacity-70">Category</Label>
        <div className="grid grid-cols-2 gap-2 mt-1">
          {categories.map(c => (
            <Button key={c} variant={c === category ? "default" : "outline"} className="rounded-xl" onClick={() => setCategory(c)}>{c}</Button>
          ))}
        </div>
      </div>
      <div>
        <Label className="text-xs opacity-70">Sort by</Label>
        <div className="grid grid-cols-2 gap-2 mt-1">
          {[
            { k: "relevance", label: "Relevance" },
            { k: "priceLow", label: "Price: Low→High" },
            { k: "priceHigh", label: "Price: High→Low" },
            { k: "rating", label: "Rating" },
          ].map(s => (
            <Button key={s.k} variant={sort === s.k ? "default" : "outline"} className="rounded-xl" onClick={() => setSort(s.k)}>{s.label}</Button>
          ))}
        </div>
      </div>
    </div>
  );
}

function Catalog() {
  const [store] = useLocalStorage(LS_STORE, { name: "X2", hero: "Minimal, fast, Amazon‑style shopping — in pure black & white." });
  const [category, setCategory] = useState<string>("All");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("relevance");
  const [active, setActive] = useState<Product | null>(null);

  const [productsLS, setProductsLS] = useLocalStorage<Product[]>(LS_PRODUCTS, DEFAULT_PRODUCTS);
  const categories = useMemo(() => {
    const cats = Array.from(new Set(productsLS.map(p => p.category)));
    return ["All", ...cats];
  }, [productsLS]);

  useEffect(() => {
    const el = document.getElementById("globalSearch") as HTMLInputElement | null;
    if (!el) return;
    const on = (e: Event) => setQuery((e.target as HTMLInputElement).value);
    el.addEventListener("input", on);
    return () => el.removeEventListener("input", on);
  }, []);

  const filtered = useMemo(() => {
    let list = productsLS.filter(p => (category === "All" || p.category === category) && (
      [p.title, p.category, p.description].join(" ").toLowerCase().includes(query.toLowerCase())
    ));
    if (sort === "priceLow") list = list.slice().sort((a,b)=>a.price-b.price);
    if (sort === "priceHigh") list = list.slice().sort((a,b)=>b.price-a.price);
    if (sort === "rating") list = list.slice().sort((a,b)=>b.rating-a.rating);
    return list;
  }, [productsLS, category, query, sort]);

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-6">
        <Filters category={category} setCategory={setCategory} query={query} setQuery={setQuery} sort={sort} setSort={setSort} categories={categories} />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(p => (
            <ProductCard key={p.id} p={p} onOpen={setActive} />
          ))}
          {filtered.length === 0 && (
            <div className="col-span-full text-sm opacity-70">No products match your search.</div>
          )}
        </div>
      </div>
      <ProductDialog product={active} onClose={() => setActive(null)} />
    </>
  );
}

function SettingsPanel({ open, setOpen }:{ open:boolean; setOpen:(v:boolean)=>void; }) {
  const [store, setStore] = useLocalStorage(LS_STORE, { name: "X2", hero: "Minimal, fast, Amazon‑style shopping — in pure black & white." });
  const [products, setProducts] = useLocalStorage<Product[]>(LS_PRODUCTS, DEFAULT_PRODUCTS);
  const [jsonText, setJsonText] = useState(JSON.stringify(products, null, 2));

  useEffect(() => setJsonText(JSON.stringify(products, null, 2)), [products]);

  const importJson = () => {
    try {
      const data = JSON.parse(jsonText) as Product[];
      if (!Array.isArray(data)) throw new Error("Expected an array of products");
      setProducts(data);
      alert("Products updated!");
    } catch (e:any) {
      alert("Invalid JSON: " + e.message);
    }
  };

  const downloadJson = () => {
    const blob = new Blob([JSON.stringify(products, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "x2-products.json"; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="rounded-2xl"><Settings className="w-5 h-5"/></Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-full sm:max-w-lg bg-black text-white">
        <SheetHeader><SheetTitle>Store Settings</SheetTitle></SheetHeader>
        <div className="p-4 space-y-6">
          <div>
            <Label>Store Name</Label>
            <div className="flex gap-2 mt-1">
              <Input value={store.name} onChange={e => setStore({ ...store, name: e.target.value })} className="bg-white text-black rounded-xl"/>
              <Button variant="outline" className="rounded-xl"><Pencil className="w-4 h-4 mr-2"/>Rename</Button>
            </div>
          </div>
          <div>
            <Label>Hero text (subtitle under Welcome)</Label>
            <Textarea value={store.hero} onChange={e => setStore({ ...store, hero: e.target.value })} className="bg-white text-black rounded-xl" rows={3}/>
          </div>
          <div className="border-t border-white/10 pt-4">
            <div className="flex items-center justify-between mb-2">
              <div className="font-semibold">Products</div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="rounded-xl" onClick={downloadJson}><Download className="w-4 h-4 mr-2"/>Export</Button>
                <Button size="sm" className="rounded-xl" onClick={importJson}><Upload className="w-4 h-4 mr-2"/>Import</Button>
              </div>
            </div>
            <Textarea value={jsonText} onChange={e => setJsonText(e.target.value)} className="bg-white text-black rounded-xl font-mono" rows={12}/>
            <div className="text-xs opacity-70 mt-2">Tip: paste your product list here (with id,title,price,rating,reviews,category,inStock,description,image) and click Import.</div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

function Header({ cartCount }:{ cartCount:number }) {
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-black/80 backdrop-blur">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-3">
        <Button variant="ghost" size="icon" className="rounded-2xl text-white"><Menu className="w-5 h-5"/></Button>
        <StoreName/>
        <div className="flex-1 max-w-3xl mx-2">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 opacity-60"/>
            <Input id="globalSearch" placeholder="Search X2 (products, brands)" className="pl-9 rounded-2xl bg-white text-black placeholder-black/50"/>
          </div>
        </div>
        <Button variant="ghost" className="rounded-2xl text-white"><User className="w-4 h-4 mr-2"/>Account</Button>
        <SettingsPanel open={false} setOpen={()=>{}}/>
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" className="rounded-2xl relative">
              <ShoppingCart className="w-4 h-4 mr-2"/>Cart
              {cartCount > 0 && (
                <span className="absolute -right-2 -top-2 text-[10px] rounded-full px-1.5 py-0.5 bg-white text-black font-bold">{cartCount}</span>
              )}
            </Button>
          </SheetTrigger>
          <CartSheet />
        </Sheet>
      </div>
    </header>
  );
}

function Footer() {
  return (
    <footer className="mt-10 border-t border-white/10 py-6 text-center text-sm opacity-70">
      © {new Date().getFullYear()} X2 • Built in monochrome. All rights reserved.
    </footer>
  );
}

export default function Page() {
  const [cartCount, setCartCount] = useState(0);
  const [store] = useLocalStorage(LS_STORE, { name: "X2", hero: "Minimal, fast, Amazon‑style shopping — in pure black & white." });

  useEffect(() => {
    const t = setInterval(() => {
      try { setCartCount((globalThis as any).__x2_cartCount?.() || 0); } catch {}
    }, 300);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="min-h-screen bg-black text-white">
      <Header cartCount={cartCount} />
      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="mb-6">
          <div className="text-2xl font-bold">Welcome to <span className="underline decoration-white/20">{store.name}</span></div>
          <div className="text-sm opacity-70">{store.hero}</div>
        </div>
        <Catalog />
        <Footer />
      </main>
    </div>
  );
}
