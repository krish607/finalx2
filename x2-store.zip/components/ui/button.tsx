import * as React from 'react';
import { cn } from '../utils';

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'default'|'outline'|'ghost';
  size?: 'sm'|'icon'|'default';
  className?: string;
};

export function Button({ variant='default', size='default', className, ...props }: Props) {
  const base = 'inline-flex items-center justify-center border rounded-2xl px-3 py-2 text-sm transition';
  const v = variant === 'outline'
    ? 'border-white/20 bg-transparent text-white hover:bg-white/10'
    : variant === 'ghost'
    ? 'border-transparent bg-transparent text-white hover:bg-white/10'
    : 'border-white/20 bg-white text-black hover:bg-white/90';
  const s = size === 'sm' ? 'h-8 text-sm px-2 py-1'
    : size === 'icon' ? 'h-9 w-9 p-0'
    : 'h-10';
  return <button className={cn(base, v, s, className)} {...props} />;
}
