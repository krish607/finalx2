'use client';
import * as React from 'react';

export function Dialog({ open, children }: { open?: boolean; children: React.ReactNode }){
  return <>{children}</>;
}
export function DialogHeader({ children }: { children: React.ReactNode }){ return <div className="mb-3">{children}</div>; }
export function DialogTitle({ children }: { children: React.ReactNode }){ return <div className="text-lg font-semibold">{children}</div>; }
export function DialogDescription({ children }: { children: React.ReactNode }){ return <div className="text-sm opacity-70">{children}</div>; }

export function DialogContent({ onInteractOutside, className='', children }:{ onInteractOutside?: ()=>void; className?: string; children: React.ReactNode; }){
  const [mounted, setMounted] = React.useState(true);
  React.useEffect(()=>{ setMounted(true); },[]);
  if(!mounted) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60" onClick={onInteractOutside}/>
      <div className={["relative mx-4 w-full max-w-2xl rounded-2xl border border-white/10 bg-black p-4", className].join(' ')}>
        {children}
      </div>
    </div>
  );
}
