import * as React from 'react';
export function DropdownMenu({ children }:{ children: React.ReactNode }){ return <div>{children}</div>; }
export function DropdownMenuTrigger({ children }:{ children: React.ReactElement }){ return children; }
export function DropdownMenuContent({ children }:{ children: React.ReactNode }){ return <div className="absolute z-50 bg-black border border-white/10 rounded-xl p-2">{children}</div>; }
export function DropdownMenuItem({ children }:{ children: React.ReactNode }){ return <div className="px-2 py-1 hover:bg-white/10 rounded">{children}</div>; }
export function DropdownMenuSeparator(){ return <div className="h-px bg-white/10 my-1"/>; }
export function DropdownMenuLabel({ children }:{ children: React.ReactNode }){ return <div className="text-xs opacity-70 px-2 py-1">{children}</div>; }
