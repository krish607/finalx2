'use client';
import * as React from 'react';

const Ctx = React.createContext<{open:boolean,setOpen:(v:boolean)=>void}|null>(null);

export function Sheet({ children }:{ children: React.ReactNode }){
  const [open, setOpen] = React.useState(false);
  return <Ctx.Provider value={{open,setOpen}}>{children}</Ctx.Provider>;
}
export function SheetTrigger({ asChild, children }:{ asChild?: boolean; children: React.ReactElement }){
  const ctx = React.useContext(Ctx)!;
  return React.cloneElement(children, { onClick: ()=>ctx.setOpen(true) });
}
export function SheetContent({ side='right', className='', children }:{ side?: 'right'|'left'; className?: string; children: React.ReactNode }){
  const ctx = React.useContext(Ctx)!;
  if(!ctx.open) return null;
  const sideCls = side==='right' ? 'right-0' : 'left-0';
  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/60" onClick={()=>ctx.setOpen(false)}/>
      <div className={["absolute top-0 h-full w-full sm:max-w-md bg-black text-white border-white/10 border ", sideCls, className].join(' ')}>
        {children}
      </div>
    </div>
  );
}
export function SheetHeader({ children }:{ children: React.ReactNode }){ return <div className="p-4 border-b border-white/10">{children}</div>; }
export function SheetTitle({ children }:{ children: React.ReactNode }){ return <div className="text-lg font-semibold">{children}</div>; }
export function SheetFooter({ children }:{ children: React.ReactNode }){ return <div className="p-4 border-t border-white/10">{children}</div>; }
